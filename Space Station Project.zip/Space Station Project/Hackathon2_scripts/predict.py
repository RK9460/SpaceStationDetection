#!/usr/bin/env python3
"""
YOLOv8 Predict (single or batch)
- Portable, no hardcoded paths
- Saves annotated images + YOLO labels with confidence
"""

import argparse
from pathlib import Path
import os
import cv2
from ultralytics import YOLO
import traceback

def save_result(res, out_images: Path, out_labels: Path):
    try:
        src = Path(getattr(res, "path", "image")).name
    except Exception:
        src = "image.png"

    # annotated image
    out_img = out_images / (src if Path(src).suffix else f"{src}.png")
    try:
        img = res.plot()  # RGB
        ok, enc = cv2.imencode(out_img.suffix or ".png",
                               cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        if ok: enc.tofile(str(out_img))
        else:  cv2.imwrite(str(out_img), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        print(f"[SAVED] {out_img}")
    except Exception as e:
        print(f"[WARN] Annotated save failed for {src}: {e}")

    # labels
    out_lbl = out_labels / (Path(src).stem + ".txt")
    try:
        with open(out_lbl, "w", encoding="utf-8") as f:
            for b in res.boxes:
                cid = int(b.cls)
                x, y, w, h = b.xywhn[0].tolist()
                conf = float(getattr(b, "conf", 0.0))
                f.write(f"{cid} {x:.6f} {y:.6f} {w:.6f} {h:.6f} {conf:.3f}\n")
        print(f"[SAVED] {out_lbl}")
    except Exception as e:
        print(f"[WARN] Label save failed for {src}: {e}")

def main():
    repo = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description="YOLOv8 prediction on file or directory.")
    parser.add_argument("--weights", required=True, help="Path to best.pt")
    parser.add_argument("--source", required=True, help="Image file or directory of images.")
    parser.add_argument("--out-images", default=str((repo/"predictions/images").resolve()))
    parser.add_argument("--out-labels", default=str((repo/"predictions/labels").resolve()))
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--iou", type=float, default=0.45)
    parser.add_argument("--augment", action="store_true")
    args = parser.parse_args()

    weights = Path(args.weights).expanduser().resolve()
    source  = Path(args.source).expanduser().resolve()
    out_i   = Path(args.out_images).expanduser().resolve()
    out_l   = Path(args.out_labels).expanduser().resolve()
    out_i.mkdir(parents=True, exist_ok=True)
    out_l.mkdir(parents=True, exist_ok=True)

    if not weights.exists():
        raise SystemExit(f"[ERROR] Weights not found: {weights}")
    if not source.exists():
        raise SystemExit(f"[ERROR] Source not found: {source}")

    print(f"[INFO] Loading model: {weights}")
    model = YOLO(str(weights))

    print(f"[INFO] Predicting on: {source}")
    results = model.predict(
        source=str(source),
        conf=args.conf,
        imgsz=args.imgsz,
        iou=args.iou,
        augment=args.augment,
        save=False
    )

    # iterate per image
    for res in results:
        save_result(res, out_i, out_l)

    print("✅ Done.")

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
