#!/usr/bin/env python3
"""
Auto-Adaptive YOLOv8 Training (4–6 GB VRAM safe)
- No hardcoded paths
- Works from repo root or from script folder
- Downloads yolov8n.pt if missing
"""

import os
import sys
import argparse
from pathlib import Path
import torch
from ultralytics import YOLO
import requests

# ---------------- helpers ----------------
def verify_or_download_model(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.stat().st_size < 1_000_000:
        print("[INFO] Downloading YOLOv8n weights...")
        url = "https://github.com/ultralytics/assets/releases/download/v0.0.0/yolov8n.pt"
        r = requests.get(url, stream=True)
        r.raise_for_status()
        with open(path, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
        print(f"[OK] Saved -> {path}")
    else:
        try:
            torch.load(str(path), map_location="cpu")
            print("[INFO] Weights verified.")
        except Exception as e:
            print(f"[WARN] Weights corrupt: {e}. Redownloading...")
            path.unlink(missing_ok=True)
            verify_or_download_model(path)

def auto_tune_memory(device: str, base_img=512, base_batch=8):
    if device == "cuda":
        total = torch.cuda.get_device_properties(0).total_memory / (1024**3)
        print(f"[INFO] GPU VRAM: {total:.1f} GB")
        if total <= 4:   return 448, 4
        if total <= 6:   return 512, 8
        return base_img, base_batch
    return 416, 2
# -----------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="Train YOLOv8 with adaptive memory settings.")
    repo = Path(__file__).resolve().parent.parent  # repo root = folder above Hackathon2_scripts
    parser.add_argument("--yaml", default=str((repo/"Hackathon2_scripts/yolo_params.yaml").resolve()),
                        help="Dataset YAML file.")
    parser.add_argument("--weights", default=str((repo/"weights/yolov8n.pt").resolve()),
                        help="Model weights path (will download if missing).")
    parser.add_argument("--results", default=str((repo/"runs/detect").resolve()),
                        help="Training results root dir.")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--device", default=("cuda" if torch.cuda.is_available() else "cpu"))
    parser.add_argument("--base-img", type=int, default=512)
    parser.add_argument("--base-batch", type=int, default=8)
    return parser.parse_args()

def main():
    args = parse_args()
    yaml_path = Path(args.yaml).expanduser().resolve()
    weights = Path(args.weights).expanduser().resolve()
    results = Path(args.results).expanduser().resolve()

    if not yaml_path.exists():
        print(f"[ERROR] Dataset YAML not found: {yaml_path}")
        sys.exit(1)

    verify_or_download_model(weights)
    imgsz, batch = auto_tune_memory(args.device, args.base_img, args.base_batch)
    print(f"[INFO] Using imgsz={imgsz}, batch={batch}")
    results.mkdir(parents=True, exist_ok=True)

    model = YOLO(str(weights))
    try:
        model.train(
            data=str(yaml_path),
            epochs=args.epochs,
            imgsz=imgsz,
            batch=batch,
            device=args.device,
            lr0=args.lr,
            optimizer="AdamW",
            amp=True,
            workers=0,                  # safe on Windows
            project=str(results),
            name="train_auto",
            exist_ok=True,
            patience=20
        )
    except torch.cuda.OutOfMemoryError:
        print("[WARN] OOM. Retrying with smaller settings...")
        if args.device == "cuda":
            torch.cuda.empty_cache()
        model.train(
            data=str(yaml_path),
            epochs=args.epochs,
            imgsz=384,
            batch=2,
            device=args.device,
            lr0=args.lr,
            optimizer="AdamW",
            amp=True,
            workers=0,
            project=str(results),
            name="train_safe",
            exist_ok=True,
            patience=15
        )

    print("\n✅ Training complete. Evaluating...")
    metrics = model.val(data=str(yaml_path), split="val")
    print(f"📊 mAP@0.5:       {metrics.box.map50:.4f}")
    print(f"📊 mAP@0.5-0.95:  {metrics.box.map:.4f}")
    print(f"📊 Precision:     {metrics.box.mp:.4f}")
    print(f"📊 Recall:        {metrics.box.mr:.4f}")
    print("🎯 Done.")

if __name__ == "__main__":
    main()
